﻿/// <autosync enabled="true" />
/// <reference path="admin.js" />
/// <reference path="bootstrap-wysiwyg.js" />
/// <reference path="comments.js" />
/// <reference path="npm.js" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery-2.1.3.js" />
/// <reference path="jquery.hotkeys.js" />